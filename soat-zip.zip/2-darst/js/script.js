const elHuw = document.querySelector('.box-list-itm-huw');
const elHours = document.querySelector('.box-list-itm-hours');
const elMuns = document.querySelector('.box-list-itm-muns');
const elSec = document.querySelector('.box-list-itm-sec');




setInterval(function () {

   const newDate = new Date()
   
   elHuw.textContent = newDate.getDay();
   elHours.textContent = newDate.getHours();
   elMuns.textContent = newDate.getMinutes();
   elSec.textContent = newDate.getSeconds();


}, 1000)







